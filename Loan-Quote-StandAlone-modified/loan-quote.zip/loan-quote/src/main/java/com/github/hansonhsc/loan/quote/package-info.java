/**
 * Provides classes that form the Loan Quote Calculator
 */
package com.github.hansonhsc.loan.quote;