package com.github.hansonhsc.loan.quote;

/**
 * A command line application that reads a CSV file of lenders and provides a quote for the requested loan amount
 * using the lenders with the lowest rates
 */
public final class LoanQuoteApplication {
    
    /**
     * Entry point for the application
     * @param args array of strings representing the user input. Must be of length 2, where <code>args[0]</code>
     *             is a file path to the input CSV file containing lender information; and <code>args[1]</code>
     *             is an integer specifying the loan amount that is between <code>MIN_LOAN_AMOUNT</code> and
     *             <code>MAX_LOAN_AMOUNT</code> inclusive and in increments of <code>LOAN_AMOUNT_INCREMENT</code>.
     */
    public static void main(final String[] args) {
        // validate number of arguments
        if (args.length != 2) {
            printError("Invalid number of arguments: " + args.length + ". Expected: 2");

            return;
        }

        // get the single quote we want
        final LoanQuote quote;
        LoanBusiness lbusiness = new LoanBusiness();
        try {
        	
        	quote = lbusiness.getQuote(args[1], args[0]);
        	
        } catch (InsufficientLendersException e) {
            printError("Insufficient offers from lenders to satisfy the loan. Try a smaller loan amount.");

            return;
        } catch (LoanQuoteParameterValidationException e) {
        	printError(e.getMessage());

            return;
		}

        // display the quote to the user
        printQuote(quote);
    }


    /**
     * Prints the quote information to the standard output
     * @param quote the <code>LoanQuote</code> object containing the quote information
     */
    private static void printQuote(final LoanQuote quote) {
        print("Requested amount: £" + quote.getLoanAmount());
        print("Rate: " + quote.getRate() + "%");
        print("Monthly repayment: £" + quote.getMonthlyRepayment());
        print("Total repayment: £" + quote.getTotalRepayment());
    }

    /**
     * Prints the specified error message to standard output as well as application usage information
     * @param message the error message to print to standard output
     */
    private static void printError(final String message) {
        print(message);
        printUsage();
    }

    /**
     * Prints a single line to the standard output to explain how to use the application
     */
    private static void printUsage() {
        print("Usage: java -jar [loan_quote_jar_file] [market_file] [loan_amount]");
    }

    /**
     * Prints the specified message to standard output. Isolated here, so that if the application ever needs logging,
     * we can integrate it here
     * @param message the message to print to standard output
     */
    private static void print(final String message) {
        System.out.println(message);
    }
}
