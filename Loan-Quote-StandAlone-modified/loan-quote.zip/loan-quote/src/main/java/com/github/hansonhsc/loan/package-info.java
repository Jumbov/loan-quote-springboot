/**
 * Provides classes related to loan calculations
 */
package com.github.hansonhsc.loan;